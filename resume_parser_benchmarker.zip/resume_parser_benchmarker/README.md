# Resume Parser — LLM Benchmarking Pipeline

A modular Python pipeline that:
1. **Parses** resumes (PDF / DOCX / TXT) into plain text
2. **Sends** each resume to 30 LLMs via Ollama's local API
3. **Extracts** technical skills + years of experience from each response
4. **Scores** every model on 4 metrics against ground-truth data
5. **Generates** a ranked leaderboard + HTML/CSV/JSON reports

---

## Project Structure

```
resume_parser_benchmarker/
├── config.py                         ← All 30 models + settings
├── main.py                           ← Entry point
├── colab_setup.py                    ← One-click Colab environment setup
├── requirements.txt
│
├── parsers/
│   └── resume_parser.py              ← PDF / DOCX / TXT text extraction
│
├── benchmarking/
│   ├── llm_client.py                 ← Unified LLM caller (Ollama / OpenAI / Anthropic / HF)
│   └── benchmark_runner.py           ← Main benchmark loop
│
├── evaluation/
│   └── evaluator.py                  ← Scoring: accuracy, coverage, years, consistency
│
├── reports/
│   └── report_generator.py           ← CSV + JSON + HTML report
│
├── data/
│   ├── resumes/                      ← ← PUT YOUR RESUME FILES HERE
│   └── ground_truth/
│       └── ground_truth.json         ← Expected skills per resume
│
└── outputs/                          ← Generated automatically
    ├── raw_results.json
    ├── scores.json
    ├── benchmark_report.csv
    ├── benchmark_report.json
    ├── benchmark_report.html          ← Open this in a browser
    └── run.log
```

---

## Quick Start

### Option A — Local (VS Code)

```bash
# 1. Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# 2. Start Ollama server (keep this running in a terminal)
ollama serve

# 3. Pull the models you want to test (example: pull 3 models)
ollama pull llama3:8b
ollama pull mistral:7b-instruct-v0.3
ollama pull gemma3:4b

# 4. Install Python dependencies
pip install -r requirements.txt

# 5. Drop your resumes into data/resumes/
cp /path/to/your/*.pdf data/resumes/

# 6. Edit data/ground_truth/ground_truth.json with correct expected skills

# 7. Run!
python main.py
```

### Option B — Google Colab

```python
# Cell 1 — clone / upload the project, then:
!python colab_setup.py                   # installs packages + starts Ollama

# Cell 2 — pull just the models you want (or --pull for all 30)
!python colab_setup.py --pull --model "llama3:8b"

# Cell 3 — upload resumes via Colab file upload widget
from google.colab import files
uploaded = files.upload()
import shutil, os
for fname, data in uploaded.items():
    shutil.move(fname, f"data/resumes/{fname}")

# Cell 4 — run the pipeline
!python main.py

# Cell 5 — display the HTML report inline
from IPython.display import IFrame
IFrame("outputs/benchmark_report.html", width="100%", height=800)
```

---

## Configuration

Edit **`config.py`** to customise:

| Setting | Purpose |
|---------|---------|
| `OLLAMA_BASE_URL` | Ollama server URL (default `http://localhost:11434`) |
| `CONSISTENCY_RUNS` | Extra calls per model for stability scoring (default 3) |
| `EVAL_WEIGHTS` | Weight of each metric in the composite score |
| `MODELS[*]["enabled"]` | Set `False` to skip a model |
| `MODELS[*]["temperature"]` | Sampling temperature per model |

---

## Scoring Metrics

| Metric | Weight | Description |
|--------|--------|-------------|
| Extraction Accuracy | 30% | Of the skills extracted, what fraction are in ground truth (precision) |
| Skill Coverage | 25% | Of the ground-truth skills, how many were found (recall) |
| Years Correctness | 30% | How accurate are the years-of-experience estimates |
| Response Consistency | 15% | How stable is the model across repeated calls |

**Composite score** = weighted average of the four metrics.

---

## Ground Truth Format

`data/ground_truth/ground_truth.json`:

```json
{
  "my_resume.pdf": {
    "skills": [
      {"skill": "Python",  "years": 4.0},
      {"skill": "Docker",  "years": 2.0},
      {"skill": "AWS",     "years": 3.0}
    ]
  }
}
```

If you don't have ground truth, the pipeline still runs — all scores will be 0 and the report will show raw extraction output only.

---

## CLI Options

```
python main.py [OPTIONS]

  --resume-dir PATH      Resume folder (default: data/resumes)
  --ground-truth PATH    Ground truth JSON path
  --output-dir PATH      Output folder (default: outputs)
  --model NAME           Run only models matching this substring
  --eval-only            Skip benchmarking, re-score existing raw_results.json
  --log-level LEVEL      DEBUG / INFO / WARNING / ERROR
```

---

## Adding Other Providers (Future)

To add OpenAI or Anthropic models, change the model's `provider` in `config.py`:

```python
{
    "name":        "GPT-4o",
    "provider":    "openai",           # ← change this
    "model_id":    "gpt-4o",
    "max_tokens":  1024,
    "temperature": 0.1,
    "enabled":     True,
},
```

Then set your API key as an environment variable:
```bash
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
```

---

## Output Files

| File | Description |
|------|-------------|
| `outputs/raw_results.json` | Complete log of every LLM call (raw text + parsed skills) |
| `outputs/scores.json` | Numeric scores per model per resume |
| `outputs/benchmark_report.csv` | Leaderboard as a flat CSV |
| `outputs/benchmark_report.json` | Full structured report |
| `outputs/benchmark_report.html` | **Interactive HTML report with charts** |
| `outputs/run.log` | Timestamped execution log |
